"use client";
import React from "react";

import { useUpload } from "../utilities/runtime-helpers";

function MainComponent() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [upload, { loading: uploading }] = useUpload();

  const fetchPosts = useCallback(async () => {
    try {
      const response = await fetch("/api/get-posts", {
        method: "POST",
        body: JSON.stringify({ limit: 10, offset }),
      });
      if (!response.ok) {
        throw new Error("Failed to fetch posts");
      }
      const data = await response.json();
      if (data.posts.length < 10) {
        setHasMore(false);
      }
      setPosts((prev) => [...prev, ...data.posts]);
    } catch (err) {
      setError("Could not load posts");
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [offset]);

  const handleLike = async (postId, userId) => {
    try {
      const response = await fetch("/api/toggle-like", {
        method: "POST",
        body: JSON.stringify({ post_id: postId, user_id: userId }),
      });
      if (!response.ok) {
        throw new Error("Failed to toggle like");
      }
      const { liked } = await response.json();
      setPosts((prev) =>
        prev.map((post) =>
          post.id === postId
            ? {
                ...post,
                like_count: liked ? post.like_count + 1 : post.like_count - 1,
              }
            : post
        )
      );
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, [fetchPosts]);

  const loadMore = useCallback(() => {
    if (!loading && hasMore) {
      setOffset((prev) => prev + 10);
    }
  }, [loading, hasMore]);

  return (
    <div className="min-h-screen bg-[#FDFBF6]">
      <header className="fixed top-0 w-full bg-[#FDFBF6] border-b-2 border-[#8B4513] z-50">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <i className="fas fa-camera text-[#8B4513] text-2xl"></i>
            <h1 className="font-crimson-text text-3xl text-[#8B4513]">
              RetroGram
            </h1>
          </div>
          <button className="px-4 py-2 bg-[#8B4513] text-[#FDFBF6] rounded hover:bg-[#654321] transition-colors font-crimson-text">
            Upload Post
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto pt-20 px-4">
        {loading && (
          <div className="flex justify-center items-center h-32">
            <div className="w-16 h-16 border-4 border-[#8B4513] rounded-full animate-spin"></div>
          </div>
        )}

        {error && (
          <div className="text-red-700 text-center py-4 font-crimson-text">
            {error}
          </div>
        )}

        <div className="grid gap-8 pb-8">
          {posts.map((post) => (
            <article
              key={post.id}
              className="bg-white border-2 border-[#8B4513] rounded-lg overflow-hidden shadow-lg"
            >
              <div className="p-4 border-b border-[#8B4513] flex items-center space-x-3">
                <img
                  src={post.avatar_url || "/default-avatar.jpg"}
                  alt={`${post.username}'s avatar`}
                  className="w-10 h-10 rounded-full object-cover border border-[#8B4513]"
                />
                <span className="font-crimson-text text-[#444444]">
                  {post.username}
                </span>
              </div>

              <div className="relative aspect-square">
                <img
                  src={post.image_url}
                  alt={post.caption}
                  className="w-full h-full object-cover filter sepia hover:sepia-0 transition-all duration-300"
                />
              </div>

              <div className="p-4">
                <div className="flex items-center space-x-4 mb-4">
                  <button
                    onClick={() => handleLike(post.id, post.user_id)}
                    className="flex items-center space-x-2 text-[#8B4513] hover:text-[#654321]"
                  >
                    <i className="fas fa-heart text-xl"></i>
                    <span className="font-crimson-text">
                      {post.like_count || 0}
                    </span>
                  </button>
                </div>

                <p className="font-courier text-[#444444] whitespace-pre-wrap mb-4">
                  {post.caption}
                </p>
              </div>
            </article>
          ))}
        </div>

        {hasMore && !loading && (
          <div className="flex justify-center pb-8">
            <button
              onClick={loadMore}
              className="px-6 py-2 bg-[#8B4513] text-[#FDFBF6] rounded hover:bg-[#654321] transition-colors font-crimson-text"
            >
              Load More
            </button>
          </div>
        )}
      </main>

      <style jsx global>{`
        @keyframes scanline {
          0% {
            transform: translateY(-100%);
          }
          100% {
            transform: translateY(100%);
          }
        }

        .scanline {
          position: absolute;
          width: 100%;
          height: 2px;
          background: rgba(255, 255, 255, 0.3);
          animation: scanline 2s linear infinite;
        }
      `}</style>
    </div>
  );
}

export default MainComponent;